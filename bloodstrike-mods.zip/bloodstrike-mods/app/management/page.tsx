'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { useRouter } from 'next/navigation';
import { FiCheck, FiX, FiUsers, FiPackage, FiFilter, FiSearch } from 'react-icons/fi';
import { format } from 'date-fns';

interface User {
  id: string;
  email: string;
  username: string;
  role: string;
  created_at: string;
}

interface Mod {
  id: string;
  name: string;
  author: string;
  status: string;
  download_count: number;
  created_at: string;
  users?: {
    username: string;
  };
}

export default function ManagementPage() {
  const { userRole } = useAuth();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'users' | 'mods'>('mods');
  const [users, setUsers] = useState<User[]>([]);
  const [mods, setMods] = useState<Mod[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (userRole !== 'admin') {
      router.push('/');
      return;
    }
    fetchData();
  }, [userRole, activeTab]);

  const fetchData = async () => {
    setIsLoading(true);
    
    if (activeTab === 'users') {
      const { data } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });
      
      setUsers(data || []);
    } else {
      const { data } = await supabase
        .from('mods')
        .select(`
          *,
          users (
            username
          )
        `)
        .order('created_at', { ascending: false });
      
      setMods(data || []);
    }
    
    setIsLoading(false);
  };

  const handleApproveMod = async (modId: string) => {
    if (!confirm('Approve this mod?')) return;
    
    await supabase
      .from('mods')
      .update({ status: 'approved' })
      .eq('id', modId);
    
    fetchData();
  };

  const handleRejectMod = async (modId: string) => {
    if (!confirm('Reject this mod?')) return;
    
    await supabase
      .from('mods')
      .update({ status: 'rejected' })
      .eq('id', modId);
    
    fetchData();
  };

  const handleDeleteMod = async (modId: string) => {
    if (!confirm('Delete this mod permanently?')) return;
    
    await supabase.from('mods').delete().eq('id', modId);
    fetchData();
  };

  const handleUpdateRole = async (userId: string, newRole: string) => {
    if (!confirm(`Change user role to ${newRole}?`)) return;
    
    await supabase
      .from('users')
      .update({ role: newRole })
      .eq('id', userId);
    
    fetchData();
  };

  if (userRole !== 'admin') {
    return null;
  }

  const filteredMods = mods.filter(mod =>
    mod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mod.author.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Management</h1>
          <p className="text-gray-600">Manage users and mod approvals</p>
        </div>
        
        {/* Tabs */}
        <div className="flex gap-2 bg-gray-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('mods')}
            className={`px-6 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'mods'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <FiPackage className="inline-block w-5 h-5 mr-2" />
            Mod Approvals
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-6 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'users'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <FiUsers className="inline-block w-5 h-5 mr-2" />
            User Management
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="glass-card rounded-2xl p-6">
        {activeTab === 'mods' ? (
          <>
            {/* Search Bar */}
            <div className="relative mb-6">
              <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search mods..."
                className="input-field pl-12"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Mods Table */}
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="skeleton h-20 rounded-xl"></div>
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-4 px-2 text-gray-700 font-semibold">Mod</th>
                      <th className="text-left py-4 px-2 text-gray-700 font-semibold">Author</th>
                      <th className="text-left py-4 px-2 text-gray-700 font-semibold">Status</th>
                      <th className="text-left py-4 px-2 text-gray-700 font-semibold">Uploaded</th>
                      <th className="text-left py-4 px-2 text-gray-700 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMods.map((mod) => (
                      <tr key={mod.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-4 px-2">
                          <div>
                            <p className="font-medium text-gray-900">{mod.name}</p>
                            <p className="text-sm text-gray-500">{mod.download_count} downloads</p>
                          </div>
                        </td>
                        <td className="py-4 px-2">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-bold">
                              {mod.users?.username?.[0]?.toUpperCase() || 'A'}
                            </div>
                            <span>{mod.author}</span>
                          </div>
                        </td>
                        <td className="py-4 px-2">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                            mod.status === 'approved'
                              ? 'bg-green-100 text-green-700'
                              : mod.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-700'
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {mod.status.charAt(0).toUpperCase() + mod.status.slice(1)}
                          </span>
                        </td>
                        <td className="py-4 px-2 text-gray-600">
                          {format(new Date(mod.created_at), 'MMM d, yyyy')}
                        </td>
                        <td className="py-4 px-2">
                          <div className="flex items-center gap-2">
                            {mod.status === 'pending' && (
                              <>
                                <button
                                  onClick={() => handleApproveMod(mod.id)}
                                  className="p-2 rounded-lg bg-green-100 text-green-700 hover:bg-green-200 transition-colors"
                                  title="Approve"
                                >
                                  <FiCheck className="w-5 h-5" />
                                </button>
                                <button
                                  onClick={() => handleRejectMod(mod.id)}
                                  className="p-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-colors"
                                  title="Reject"
                                >
                                  <FiX className="w-5 h-5" />
                                </button>
                              </>
                            )}
                            <button
                              onClick={() => handleDeleteMod(mod.id)}
                              className="p-2 rounded-lg bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors text-sm"
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        ) : (
          /* Users Table */
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-2 text-gray-700 font-semibold">User</th>
                  <th className="text-left py-4 px-2 text-gray-700 font-semibold">Email</th>
                  <th className="text-left py-4 px-2 text-gray-700 font-semibold">Role</th>
                  <th className="text-left py-4 px-2 text-gray-700 font-semibold">Joined</th>
                  <th className="text-left py-4 px-2 text-gray-700 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4 px-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold">
                          {user.username?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{user.username}</p>
                          <p className="text-sm text-gray-500">ID: {user.id.slice(0, 8)}...</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-2 text-gray-600">{user.email}</td>
                    <td className="py-4 px-2">
                      <select
                        value={user.role}
                        onChange={(e) => handleUpdateRole(user.id, e.target.value)}
                        className="px-3 py-1 rounded-lg border border-gray-300 focus:border-purple-500 focus:ring-2 focus:ring-purple-200 outline-none"
                      >
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>
                    <td className="py-4 px-2 text-gray-600">
                      {format(new Date(user.created_at), 'MMM d, yyyy')}
                    </td>
                    <td className="py-4 px-2">
                      <button
                        onClick={() => {
                          if (confirm('Delete this user?')) {
                            // Note: In production, you might want to soft delete
                            supabase.from('users').delete().eq('id', user.id);
                            fetchData();
                          }
                        }}
                        className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Users</p>
              <h3 className="text-2xl font-bold mt-2">{users.length}</h3>
            </div>
            <FiUsers className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Mods</p>
              <h3 className="text-2xl font-bold mt-2">
                {mods.filter(m => m.status === 'pending').length}
              </h3>
            </div>
            <FiPackage className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
        
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Approved Mods</p>
              <h3 className="text-2xl font-bold mt-2">
                {mods.filter(m => m.status === 'approved').length}
              </h3>
            </div>
            <FiCheck className="w-8 h-8 text-green-500" />
          </div>
        </div>
      </div>
    </div>
  );
}