import type { Metadata } from 'next';
import { Nunito } from 'next/font/google';
import './globals.css';
import Navbar from '@/components/Navbar';
import { AuthProvider } from '@/components/AuthProvider';

const nunito = Nunito({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'BloodStrike Mods Hub',
  description: 'Download and share BloodStrike mods',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${nunito.className} bg-gray-50 text-gray-900 min-h-screen`}>
        <AuthProvider>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-1 container mx-auto px-4 py-8">
              {children}
            </main>
            <footer className="border-t border-gray-200 py-6 mt-12">
              <div className="container mx-auto px-4 text-center text-gray-600">
                <p>© 2024 BloodStrike Mods Hub. All rights reserved.</p>
                <p className="text-sm mt-2">This website is not affiliated with BloodStrike.</p>
              </div>
            </footer>
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}