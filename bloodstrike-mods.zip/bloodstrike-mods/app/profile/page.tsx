'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { useRouter } from 'next/navigation';
import { FiUser, FiMail, FiSave, FiCamera, FiLock } from 'react-icons/fi';

export default function ProfilePage() {
  const { user, refreshSession } = useAuth();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [isPasswordLoading, setIsPasswordLoading] = useState(false);
  const [profileData, setProfileData] = useState({
    username: '',
    email: '',
    avatar_url: ''
  });
  const [passwordData, setPasswordData] = useState({
    current: '',
    new: '',
    confirm: ''
  });
  const [stats, setStats] = useState({
    uploads: 0,
    downloads: 0,
    comments: 0
  });

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchStats();
    }
  }, [user]);

  const fetchProfile = async () => {
    const { data } = await supabase
      .from('users')
      .select('username, avatar_url')
      .eq('id', user?.id)
      .single();

    if (data) {
      setProfileData({
        username: data.username || '',
        avatar_url: data.avatar_url || '',
        email: user?.email || ''
      });
    }
  };

  const fetchStats = async () => {
    // Uploads count
    const { count: uploads } = await supabase
      .from('mods')
      .select('*', { count: 'exact', head: true })
      .eq('uploader_id', user?.id);

    // Downloads count
    const { count: downloads } = await supabase
      .from('downloads')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user?.id);

    // Comments count
    const { count: comments } = await supabase
      .from('comments')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user?.id);

    setStats({
      uploads: uploads || 0,
      downloads: downloads || 0,
      comments: comments || 0
    });
  };

  const handleSaveProfile = async () => {
    setIsLoading(true);
    
    const { error } = await supabase
      .from('users')
      .update({
        username: profileData.username,
        avatar_url: profileData.avatar_url
      })
      .eq('id', user?.id);

    if (error) {
      alert('Error updating profile: ' + error.message);
    } else {
      await refreshSession();
      alert('Profile updated successfully!');
    }
    
    setIsLoading(false);
  };

  const handleChangePassword = async () => {
    if (passwordData.new !== passwordData.confirm) {
      alert('New passwords do not match');
      return;
    }

    setIsPasswordLoading(true);
    
    const { error } = await supabase.auth.updateUser({
      password: passwordData.new
    });

    if (error) {
      alert('Error changing password: ' + error.message);
    } else {
      setPasswordData({ current: '', new: '', confirm: '' });
      alert('Password changed successfully!');
    }
    
    setIsPasswordLoading(false);
  };

  if (!user) {
    router.push('/auth');
    return null;
  }

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-2 space-y-8">
          {/* Basic Info Card */}
          <div className="glass-card rounded-2xl p-8">
            <div className="flex items-center gap-4 mb-8">
              <div className="relative">
                {profileData.avatar_url ? (
                  <img
                    src={profileData.avatar_url}
                    alt={profileData.username}
                    className="w-20 h-20 rounded-2xl object-cover"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white text-2xl font-bold">
                    {profileData.username?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase()}
                  </div>
                )}
                <button className="absolute -bottom-2 -right-2 bg-gray-800 text-white p-2 rounded-full hover:bg-gray-900 transition-colors">
                  <FiCamera className="w-4 h-4" />
                </button>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Profile Settings</h2>
                <p className="text-gray-600">Manage your account information</p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Username
                </label>
                <div className="relative">
                  <FiUser className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    className="input-field pl-12"
                    value={profileData.username}
                    onChange={(e) => setProfileData({...profileData, username: e.target.value})}
                    placeholder="Choose a username"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <div className="relative">
                  <FiMail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="email"
                    disabled
                    className="input-field pl-12 bg-gray-50"
                    value={profileData.email}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Avatar URL
                </label>
                <div className="relative">
                  <FiCamera className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="url"
                    className="input-field pl-12"
                    value={profileData.avatar_url}
                    onChange={(e) => setProfileData({...profileData, avatar_url: e.target.value})}
                    placeholder="https://example.com/avatar.jpg"
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Enter a direct image URL for your profile picture
                </p>
              </div>

              <button
                onClick={handleSaveProfile}
                disabled={isLoading || !profileData.username}
                className="w-full btn-primary py-4 mt-4"
              >
                <FiSave className="inline-block w-5 h-5 mr-2" />
                {isLoading ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>

          {/* Password Card */}
          <div className="glass-card rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-gradient-to-r from-red-500 to-orange-500 p-3 rounded-xl">
                <FiLock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Change Password</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Current Password
                </label>
                <input
                  type="password"
                  className="input-field"
                  value={passwordData.current}
                  onChange={(e) => setPasswordData({...passwordData, current: e.target.value})}
                  placeholder="••••••••"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  New Password
                </label>
                <input
                  type="password"
                  className="input-field"
                  value={passwordData.new}
                  onChange={(e) => setPasswordData({...passwordData, new: e.target.value})}
                  placeholder="••••••••"
                  minLength={6}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  className="input-field"
                  value={passwordData.confirm}
                  onChange={(e) => setPasswordData({...passwordData, confirm: e.target.value})}
                  placeholder="••••••••"
                  minLength={6}
                />
              </div>

              <button
                onClick={handleChangePassword}
                disabled={isPasswordLoading || !passwordData.new || !passwordData.confirm}
                className="w-full bg-gradient-to-r from-red-500 to-orange-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-red-600 hover:to-orange-600 transition-all disabled:opacity-50"
              >
                {isPasswordLoading ? 'Changing...' : 'Change Password'}
              </button>
            </div>
          </div>
        </div>

        {/* Stats Card */}
        <div>
          <div className="glass-card rounded-2xl p-6 sticky top-24">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Your Stats</h3>
            
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6">
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  {stats.uploads}
                </div>
                <p className="text-gray-600">Mods Uploaded</p>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6">
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  {stats.downloads}
                </div>
                <p className="text-gray-600">Files Downloaded</p>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6">
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  {stats.comments}
                </div>
                <p className="text-gray-600">Comments Made</p>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-3">Account Status</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Email Verified</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    user.email_confirmed_at
                      ? 'bg-green-100 text-green-700'
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {user.email_confirmed_at ? 'Verified' : 'Pending'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Account Created</span>
                  <span className="text-gray-900 font-medium">
                    {new Date(user.created_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}