'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { useRouter } from 'next/navigation';
import { FiUpload, FiX, FiPlus } from 'react-icons/fi';

const FEATURES_OPTIONS = [
  'Aimbot', 'Wallhack', 'ESP', 'No Recoil', 'No Spread',
  'Skin Hack', 'Speed Hack', 'Auto Headshot', 'Radar Hack',
  'Bunny Hop', 'Triggerbot', 'Fly Hack', 'God Mode'
];

export default function UploadPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [features, setFeatures] = useState<string[]>([]);
  const [customFeature, setCustomFeature] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    author: '',
    author_contact: '',
    download_url: '',
    price: 'free',
    mod_key: '',
    key_expiry_duration: 'permanent',
    mod_durability: '1 day',
    architecture: '64-bit',
    description: ''
  });

  if (!user) {
    return (
      <div className="text-center py-12">
        <div className="glass-card rounded-2xl p-8 max-w-md mx-auto">
          <div className="text-red-500 mb-4">
            <FiUpload className="w-16 h-16 mx-auto" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Authentication Required</h2>
          <p className="text-gray-600 mb-6">
            You need to be logged in to upload mods. Please sign in or create an account.
          </p>
          <a href="/auth" className="btn-primary inline-block">
            Go to Login
          </a>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { error } = await supabase.from('mods').insert({
        ...formData,
        features,
        uploader_id: user.id,
        expires_at: formData.mod_durability === 'permanent' 
          ? null 
          : new Date(Date.now() + getDurationMs(formData.mod_durability)).toISOString()
      });

      if (error) throw error;

      alert('Mod uploaded successfully! It will appear in the store after admin approval.');
      router.push('/');
    } catch (error: any) {
      alert('Error uploading mod: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getDurationMs = (duration: string) => {
    const match = duration.match(/(\d+)\s*(day|month|year)/i);
    if (!match) return 0;
    
    const [, num, unit] = match;
    const number = parseInt(num);
    
    switch (unit.toLowerCase()) {
      case 'day': return number * 24 * 60 * 60 * 1000;
      case 'month': return number * 30 * 24 * 60 * 60 * 1000;
      case 'year': return number * 365 * 24 * 60 * 60 * 1000;
      default: return 0;
    }
  };

  const addCustomFeature = () => {
    if (customFeature.trim() && !features.includes(customFeature.trim())) {
      setFeatures([...features, customFeature.trim()]);
      setCustomFeature('');
    }
  };

  const removeFeature = (feature: string) => {
    setFeatures(features.filter(f => f !== feature));
  };

  return (
    <div className="max-w-3xl mx-auto animate-fade-in">
      <div className="glass-card rounded-2xl p-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-xl">
            <FiUpload className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Upload Mod</h1>
            <p className="text-gray-600">Share your BloodStrike mod with the community</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mod Name *
              </label>
              <input
                type="text"
                required
                className="input-field"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="e.g., Ultimate Aimbot Pro"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Author Name *
              </label>
              <input
                type="text"
                required
                className="input-field"
                value={formData.author}
                onChange={(e) => setFormData({...formData, author: e.target.value})}
                placeholder="Your name or alias"
              />
            </div>
          </div>

          {/* Contact & URL */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Contact Information (Telegram, WhatsApp, Discord)
            </label>
            <input
              type="text"
              className="input-field"
              value={formData.author_contact}
              onChange={(e) => setFormData({...formData, author_contact: e.target.value})}
              placeholder="@username or link"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Download URL *
            </label>
            <input
              type="url"
              required
              className="input-field"
              value={formData.download_url}
              onChange={(e) => setFormData({...formData, download_url: e.target.value})}
              placeholder="https://example.com/mod.zip"
            />
          </div>

          {/* Price & Key */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Price
              </label>
              <select
                className="input-field"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
              >
                <option value="free">Free</option>
                <option value="paid">Paid</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mod Key (Optional)
              </label>
              <input
                type="text"
                className="input-field"
                value={formData.mod_key}
                onChange={(e) => setFormData({...formData, mod_key: e.target.value})}
                placeholder="License key or leave empty"
              />
            </div>

            {formData.mod_key && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Key Expiry
                </label>
                <select
                  className="input-field"
                  value={formData.key_expiry_duration}
                  onChange={(e) => setFormData({...formData, key_expiry_duration: e.target.value})}
                >
                  <option value="permanent">Permanent</option>
                  <option value="1 day">1 Day</option>
                  <option value="3 days">3 Days</option>
                  <option value="7 days">7 Days</option>
                  <option value="30 days">30 Days</option>
                  <option value="custom">Custom</option>
                </select>
              </div>
            )}
          </div>

          {/* Durability & Architecture */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mod Durability *
              </label>
              <select
                required
                className="input-field"
                value={formData.mod_durability}
                onChange={(e) => setFormData({...formData, mod_durability: e.target.value})}
              >
                <option value="1 day">1 Day</option>
                <option value="3 days">3 Days</option>
                <option value="7 days">7 Days</option>
                <option value="30 days">30 Days</option>
                <option value="permanent">Permanent</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Architecture
              </label>
              <select
                className="input-field"
                value={formData.architecture}
                onChange={(e) => setFormData({...formData, architecture: e.target.value})}
              >
                <option value="64-bit">64-bit</option>
                <option value="32-bit">32-bit</option>
                <option value="both">Both</option>
              </select>
            </div>
          </div>

          {/* Features */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Features *
            </label>
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {FEATURES_OPTIONS.map((feature) => (
                  <button
                    key={feature}
                    type="button"
                    onClick={() => {
                      if (features.includes(feature)) {
                        removeFeature(feature);
                      } else {
                        setFeatures([...features, feature]);
                      }
                    }}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      features.includes(feature)
                        ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {feature}
                  </button>
                ))}
              </div>

              {/* Custom Feature Input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  className="input-field flex-1"
                  value={customFeature}
                  onChange={(e) => setCustomFeature(e.target.value)}
                  placeholder="Add custom feature"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomFeature())}
                />
                <button
                  type="button"
                  onClick={addCustomFeature}
                  className="px-4 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  <FiPlus className="w-5 h-5" />
                </button>
              </div>

              {/* Selected Features */}
              {features.length > 0 && (
                <div>
                  <p className="text-sm text-gray-600 mb-2">Selected Features:</p>
                  <div className="flex flex-wrap gap-2">
                    {features.map((feature) => (
                      <span
                        key={feature}
                        className="px-3 py-1 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 rounded-full text-sm font-medium flex items-center gap-2"
                      >
                        {feature}
                        <button
                          type="button"
                          onClick={() => removeFeature(feature)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <FiX className="w-4 h-4" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description *
            </label>
            <textarea
              required
              className="input-field min-h-[150px] resize-none"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Describe your mod, its features, installation instructions, etc."
              maxLength={1000}
            />
            <p className="text-sm text-gray-500 mt-2">
              {formData.description.length}/1000 characters
            </p>
          </div>

          {/* Submit Button */}
          <div className="pt-6 border-t border-gray-200">
            <button
              type="submit"
              disabled={isLoading || features.length === 0}
              className="w-full btn-primary py-4"
            >
              {isLoading ? 'Uploading...' : 'Upload Mod for Review'}
            </button>
            <p className="text-sm text-gray-500 text-center mt-4">
              Your mod will be reviewed by admins before appearing in the store
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}