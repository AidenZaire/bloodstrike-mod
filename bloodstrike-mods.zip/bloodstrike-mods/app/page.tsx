'use client';

import { useState, useEffect } from 'react';
import ModCard from '@/components/ModCard';
import AnalyticsDashboard from '@/components/AnalyticsDashboard';
import { supabase } from '@/lib/supabase';
import { FiSearch, FiGrid, FiList, FiFilter } from 'react-icons/fi';
import { useAuth } from '@/components/AuthProvider';

interface Mod {
  id: string;
  name: string;
  author: string;
  download_url: string;
  price: string;
  mod_key: string;
  key_expiry_duration: string;
  mod_durability: string;
  architecture: string;
  description: string;
  features: string[];
  download_count: number;
  created_at: string;
  expires_at: string;
  status: string;
  users?: {
    username: string;
    avatar_url: string;
  };
}

export default function HomePage() {
  const [mods, setMods] = useState<Mod[]>([]);
  const [filteredMods, setFilteredMods] = useState<Mod[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({
    price: 'all',
    architecture: 'all',
    sortBy: 'newest'
  });

  useEffect(() => {
    fetchMods();
  }, []);

  useEffect(() => {
    filterMods();
  }, [searchQuery, filters, mods]);

  const fetchMods = async () => {
    const { data, error } = await supabase
      .from('mods')
      .select(`
        *,
        users (
          username,
          avatar_url
        )
      `)
      .eq('status', 'approved')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setMods(data);
      setFilteredMods(data);
    }
    setIsLoading(false);
  };

  const filterMods = () => {
    let filtered = [...mods];

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(mod =>
        mod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Price filter
    if (filters.price !== 'all') {
      filtered = filtered.filter(mod => mod.price === filters.price);
    }

    // Architecture filter
    if (filters.architecture !== 'all') {
      filtered = filtered.filter(mod => mod.architecture === filters.architecture);
    }

    // Sort
    switch (filters.sortBy) {
      case 'newest':
        filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        break;
      case 'popular':
        filtered.sort((a, b) => b.download_count - a.download_count);
        break;
      case 'oldest':
        filtered.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        break;
    }

    setFilteredMods(filtered);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Analytics Dashboard */}
      <AnalyticsDashboard />

      {/* Search and Filters */}
      <div className="glass-card rounded-2xl p-6">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          {/* Search Bar */}
          <div className="relative flex-1 w-full">
            <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search mods by name, author, or features..."
              className="input-field pl-12"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* View Toggle */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-3 rounded-xl ${viewMode === 'grid' ? 'bg-purple-100 text-purple-600' : 'bg-gray-100'}`}
            >
              <FiGrid className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-3 rounded-xl ${viewMode === 'list' ? 'bg-purple-100 text-purple-600' : 'bg-gray-100'}`}
            >
              <FiList className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Advanced Filters */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <select
            className="input-field"
            value={filters.price}
            onChange={(e) => setFilters({...filters, price: e.target.value})}
          >
            <option value="all">All Prices</option>
            <option value="free">Free</option>
            <option value="paid">Paid</option>
          </select>

          <select
            className="input-field"
            value={filters.architecture}
            onChange={(e) => setFilters({...filters, architecture: e.target.value})}
          >
            <option value="all">All Architectures</option>
            <option value="32-bit">32-bit</option>
            <option value="64-bit">64-bit</option>
            <option value="both">Both</option>
          </select>

          <select
            className="input-field"
            value={filters.sortBy}
            onChange={(e) => setFilters({...filters, sortBy: e.target.value})}
          >
            <option value="newest">Newest First</option>
            <option value="popular">Most Popular</option>
            <option value="oldest">Oldest First</option>
          </select>
        </div>
      </div>

      {/* Mods Grid/List */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="skeleton h-96 rounded-2xl"></div>
          ))}
        </div>
      ) : filteredMods.length === 0 ? (
        <div className="text-center py-12 glass-card rounded-2xl">
          <div className="text-gray-400 mb-4">
            <FiSearch className="w-16 h-16 mx-auto" />
          </div>
          <h3 className="text-xl font-semibold text-gray-600">No mods found</h3>
          <p className="text-gray-500 mt-2">Try adjusting your search or filters</p>
        </div>
      ) : (
        <div className={viewMode === 'grid' 
          ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
          : 'space-y-4'
        }>
          {filteredMods.map((mod) => (
            <ModCard key={mod.id} mod={mod} viewMode={viewMode} />
          ))}
        </div>
      )}
    </div>
  );
}