'use client';

import { useState } from 'react';
import { FiDownload, FiMessageSquare, FiStar, FiClock } from 'react-icons/fi';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import CommentsSection from './CommentsSection';

interface ModCardProps {
  mod: {
    id: string;
    name: string;
    author: string;
    download_url: string;
    price: string;
    mod_key: string;
    key_expiry_duration: string;
    mod_durability: string;
    architecture: string;
    description: string;
    features: string[];
    download_count: number;
    created_at: string;
    expires_at: string;
    users?: {
      username: string;
      avatar_url: string;
    };
  };
  viewMode: 'grid' | 'list';
}

export default function ModCard({ mod, viewMode }: ModCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [downloadCount, setDownloadCount] = useState(mod.download_count);
  const { user } = useAuth();

  const isKeyExpired = mod.key_expiry_duration && mod.key_expiry_duration !== 'permanent' 
    ? new Date(mod.expires_at) < new Date()
    : false;

  const handleDownload = async () => {
    if (!user) {
      // Check guest download limit
      const today = new Date().toISOString().split('T')[0];
      const downloadsToday = localStorage.getItem(`downloads_${today}`);
      const count = downloadsToday ? parseInt(downloadsToday) : 0;
      
      if (count >= 2) {
        alert('Guests are limited to 2 downloads per day. Please sign up for unlimited downloads.');
        return;
      }
      
      localStorage.setItem(`downloads_${today}`, (count + 1).toString());
    }

    // Record download
    await supabase.from('downloads').insert({
      mod_id: mod.id,
      user_id: user?.id || null
    });

    // Update download count
    await supabase
      .from('mods')
      .update({ download_count: mod.download_count + 1 })
      .eq('id', mod.id);

    setDownloadCount(prev => prev + 1);

    // Trigger download
    window.open(mod.download_url, '_blank');
  };

  if (viewMode === 'list') {
    return (
      <div className="glass-card rounded-2xl p-6 card-hover">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Mod Info */}
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xl font-bold text-gray-900">{mod.name}</h3>
                <p className="text-gray-600 mt-1">By {mod.author}</p>
              </div>
              <span className={`px-4 py-1 rounded-full text-sm font-semibold ${
                mod.price === 'free' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                {mod.price === 'free' ? 'FREE' : 'PAID'}
              </span>
            </div>

            <p className="text-gray-700 mt-3 line-clamp-2">{mod.description}</p>

            {/* Features */}
            <div className="flex flex-wrap gap-2 mt-4">
              {mod.features?.map((feature, index) => (
                <span 
                  key={index}
                  className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium"
                >
                  {feature}
                </span>
              ))}
            </div>

            {/* Stats */}
            <div className="flex items-center gap-6 mt-4 text-sm text-gray-600">
              <span className="flex items-center gap-1">
                <FiDownload className="w-4 h-4" />
                {downloadCount} downloads
              </span>
              <span className="flex items-center gap-1">
                <FiClock className="w-4 h-4" />
                {mod.mod_durability}
              </span>
              <span className={`flex items-center gap-1 ${
                isKeyExpired ? 'text-red-600' : 'text-green-600'
              }`}>
                <FiStar className="w-4 h-4" />
                {isKeyExpired ? 'Key Expired' : 'Active'}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-3">
            <button
              onClick={handleDownload}
              className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                isKeyExpired
                  ? 'bg-red-100 text-red-700 hover:bg-red-200'
                  : 'btn-primary'
              }`}
              disabled={isKeyExpired}
            >
              <FiDownload className="inline-block w-5 h-5 mr-2" />
              Download {mod.price === 'paid' && '(Paid)'}
            </button>
            <button
              onClick={() => setShowComments(!showComments)}
              className="px-6 py-3 rounded-xl bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors font-semibold"
            >
              <FiMessageSquare className="inline-block w-5 h-5 mr-2" />
              Comments
            </button>
          </div>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="mt-6 border-t border-gray-200 pt-6">
            <CommentsSection modId={mod.id} />
          </div>
        )}
      </div>
    );
  }

  // Grid View
  return (
    <div className="glass-card rounded-2xl overflow-hidden card-hover flex flex-col h-full">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="text-lg font-bold text-gray-900 line-clamp-1">{mod.name}</h3>
            <p className="text-sm text-gray-600 mt-1">By {mod.author}</p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
            mod.price === 'free' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
          }`}>
            {mod.price === 'free' ? 'FREE' : 'PAID'}
          </span>
        </div>

        {/* Features */}
        <div className="flex flex-wrap gap-1 mb-3">
          {mod.features?.slice(0, 3).map((feature, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-medium"
            >
              {feature}
            </span>
          ))}
          {mod.features && mod.features.length > 3 && (
            <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
              +{mod.features.length - 3}
            </span>
          )}
        </div>

        {/* Description */}
        <p className="text-gray-700 text-sm line-clamp-2 mb-4">{mod.description}</p>

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-gray-600">
          <span className="flex items-center gap-1">
            <FiDownload className="w-4 h-4" />
            {downloadCount}
          </span>
          <span className={`flex items-center gap-1 ${
            isKeyExpired ? 'text-red-600' : 'text-green-600'
          }`}>
            <FiStar className="w-4 h-4" />
            {isKeyExpired ? 'Expired' : 'Active'}
          </span>
          <span className="flex items-center gap-1">
            <FiClock className="w-4 h-4" />
            {mod.mod_durability}
          </span>
        </div>
      </div>

      {/* Footer */}
      <div className="p-6 pt-4 border-t border-gray-100 mt-auto">
        <div className="flex gap-3">
          <button
            onClick={handleDownload}
            className={`flex-1 py-2 rounded-xl font-semibold transition-all ${
              isKeyExpired
                ? 'bg-red-100 text-red-700 hover:bg-red-200'
                : 'btn-primary'
            }`}
            disabled={isKeyExpired}
          >
            <FiDownload className="inline-block w-4 h-4 mr-2" />
            Download
          </button>
          <button
            onClick={() => setShowComments(!showComments)}
            className="p-2 rounded-xl bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
            title="Comments"
          >
            <FiMessageSquare className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Comments Overlay */}
      {showComments && (
        <div className="absolute inset-0 bg-white/95 backdrop-blur-sm z-10 p-6 overflow-auto">
          <button
            onClick={() => setShowComments(false)}
            className="absolute top-4 right-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200"
          >
            ×
          </button>
          <CommentsSection modId={mod.id} />
        </div>
      )}
    </div>
  );
}