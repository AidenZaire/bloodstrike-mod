'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/components/AuthProvider';
import { 
  FiHome, FiUpload, FiUser, FiSettings, 
  FiLogIn, FiLogOut, FiMenu, FiX,
  FiShoppingBag, FiBarChart2
} from 'react-icons/fi';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, userRole, signOut, isLoading } = useAuth();

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-xl bg-white/80 border-b border-gray-200/50 shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-red-600 to-purple-600 w-10 h-10 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">BS</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-purple-600 bg-clip-text text-transparent">
                BloodStrike Mods
              </h1>
              <p className="text-xs text-gray-500">iOS 24 Inspired Design</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-2">
            <Link href="/" className="flex items-center space-x-2 px-4 py-2 rounded-xl hover:bg-gray-100 transition-colors">
              <FiHome className="w-5 h-5" />
              <span>Store</span>
            </Link>
            
            <Link href="/upload" className="flex items-center space-x-2 px-4 py-2 rounded-xl hover:bg-gray-100 transition-colors">
              <FiUpload className="w-5 h-5" />
              <span>Upload</span>
            </Link>

            {userRole === 'admin' && (
              <Link href="/management" className="flex items-center space-x-2 px-4 py-2 rounded-xl hover:bg-gray-100 transition-colors">
                <FiSettings className="w-5 h-5" />
                <span>Management</span>
              </Link>
            )}

            {user ? (
              <>
                <Link href="/profile" className="flex items-center space-x-2 px-4 py-2 rounded-xl hover:bg-gray-100 transition-colors">
                  <FiUser className="w-5 h-5" />
                  <span>Profile</span>
                </Link>
                <button
                  onClick={signOut}
                  className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
                >
                  <FiLogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <Link href="/auth" className="flex items-center space-x-2 px-4 py-2 rounded-xl btn-primary">
                <FiLogIn className="w-5 h-5" />
                <span>Login</span>
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isMenuOpen ? <FiX className="w-6 h-6" /> : <FiMenu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 animate-fade-in">
            <div className="flex flex-col space-y-2 p-4 glass-card rounded-2xl">
              <Link 
                href="/" 
                className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                <FiHome className="w-5 h-5" />
                <span>Store</span>
              </Link>
              
              <Link 
                href="/upload" 
                className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                <FiUpload className="w-5 h-5" />
                <span>Upload</span>
              </Link>

              {userRole === 'admin' && (
                <Link 
                  href="/management" 
                  className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <FiSettings className="w-5 h-5" />
                  <span>Management</span>
                </Link>
              )}

              {user ? (
                <>
                  <Link 
                    href="/profile" 
                    className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <FiUser className="w-5 h-5" />
                    <span>Profile</span>
                  </Link>
                  <button
                    onClick={() => {
                      signOut();
                      setIsMenuOpen(false);
                    }}
                    className="flex items-center space-x-3 p-3 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 transition-colors text-left"
                  >
                    <FiLogOut className="w-5 h-5" />
                    <span>Logout</span>
                  </button>
                </>
              ) : (
                <Link 
                  href="/auth" 
                  className="flex items-center space-x-3 p-3 rounded-xl btn-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <FiLogIn className="w-5 h-5" />
                  <span>Login</span>
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}