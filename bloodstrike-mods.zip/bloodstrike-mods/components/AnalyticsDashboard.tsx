'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { FiUsers, FiPackage, FiDownload, FiTrendingUp } from 'react-icons/fi';

export default function AnalyticsDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalMods: 0,
    totalDownloads: 0,
    trendingMods: 0
  });

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    // Get total users
    const { count: userCount } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true });

    // Get total approved mods
    const { count: modCount } = await supabase
      .from('mods')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'approved');

    // Get total downloads
    const { count: downloadCount } = await supabase
      .from('downloads')
      .select('*', { count: 'exact', head: true });

    // Get trending mods (mods with > 100 downloads)
    const { count: trendingCount } = await supabase
      .from('mods')
      .select('*', { count: 'exact', head: true })
      .gte('download_count', 100);

    setStats({
      totalUsers: userCount || 0,
      totalMods: modCount || 0,
      totalDownloads: downloadCount || 0,
      trendingMods: trendingCount || 0
    });
  };

  const statCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers.toLocaleString(),
      icon: FiUsers,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Total Mods',
      value: stats.totalMods.toLocaleString(),
      icon: FiPackage,
      color: 'from-purple-500 to-pink-500'
    },
    {
      title: 'Total Downloads',
      value: stats.totalDownloads.toLocaleString(),
      icon: FiDownload,
      color: 'from-green-500 to-emerald-500'
    },
    {
      title: 'Trending Mods',
      value: stats.trendingMods.toLocaleString(),
      icon: FiTrendingUp,
      color: 'from-orange-500 to-red-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <div 
          key={stat.title} 
          className="glass-card rounded-2xl p-6 card-hover animate-fade-in"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{stat.title}</p>
              <h3 className="text-3xl font-bold mt-2">{stat.value}</h3>
            </div>
            <div className={`bg-gradient-to-br ${stat.color} p-3 rounded-xl`}>
              <stat.icon className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="mt-4 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className={`h-full bg-gradient-to-r ${stat.color}`}
              style={{ width: `${(parseInt(stat.value) % 100)}%` }}
            ></div>
          </div>
        </div>
      ))}
    </div>
  );
}